// ISxvShellService.aidl
package com.sxv.gamespace;

// Interface yang dijalankan di dalam proses ber-privilese shell/system
// (dibuat oleh Shizuku.bindUserService()). Semua pemanggilan method di
// sini dieksekusi dengan UID yang diberikan Shizuku, BUKAN UID aplikasi
// biasa — karena itu setiap command yang masuk WAJIB sudah lolos
// validasi native (SxvCoreEngine::validateCommand) sebelum sampai sini.
interface ISxvShellService {

    // Menjalankan satu baris perintah shell (tanpa prefix "adb shell")
    // dan mengembalikan stdout+stderr sebagai String tunggal.
    String exec(String command);

    // Versi non-blocking yang hanya melempar command tanpa menunggu
    // output — dipakai untuk aksi "fire and forget" seperti kill task.
    void execFireAndForget(String command);

    // Mengembalikan UID proses layanan ini berjalan (untuk verifikasi
    // di sisi Kotlin bahwa privilese benar-benar didapat).
    int getRunningUid();
}
