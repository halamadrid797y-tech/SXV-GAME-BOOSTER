package com.sxv.gamespace

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat

/**
 * FloatingService
 * ------------------------------------------------------------
 * - Berjalan sebagai ForegroundService (notifikasi persisten)
 *   supaya SXV Core tidak dihentikan paksa oleh sistem.
 * - Menampilkan Jendela Mengambang native (WindowManager, BUKAN
 *   WebView) berupa bubble yang bisa di-drag, dan panel dengan
 *   3 Mode Performa saat bubble di-tap.
 */
class FloatingService : Service() {

    enum class PerfMode { BALANCED, POWER_SAVER, EXTREME }

    companion object {
        private const val CHANNEL_ID = "sxv_core_channel"
        private const val NOTIF_ID = 501
        const val ACTION_STOP = "com.sxv.gamespace.action.STOP_CORE"

        private const val BALANCED_POLL_MS = 2000L
        private const val POWER_SAVER_POLL_MS = 5000L
        private const val EXTREME_POLL_MS = 1000L
    }

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private var currentMode: PerfMode = PerfMode.BALANCED
    private val statsHandler = Handler(Looper.getMainLooper())
    private var pollIntervalMs = BALANCED_POLL_MS

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification(uptimeText = "00:00:00"))
        addFloatingBubble()
        startStatsPolling()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        statsHandler.removeCallbacksAndMessages(null)
        removeFloatingViews()
        super.onDestroy()
    }

    // ==========================================================
    // NOTIFIKASI KUSTOM (Custom Notification Controller)
    // ==========================================================
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SXV Core",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Status SXV Core Engine"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(uptimeText: String): Notification {
        val stopIntent = Intent(this, FloatingService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done) // ganti ikon SV kustom
            .setContentTitle("SXV Core Active")
            .setContentText("Mode: ${currentMode.label()} · Uptime $uptimeText")
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(0, "Hentikan", stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(uptimeText: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(uptimeText))
    }

    // ==========================================================
    // FLOATING BUBBLE (WindowManager overlay)
    // ==========================================================
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun addFloatingBubble() {
        val inflater = LayoutInflater.from(this)
        val bubble = inflater.inflate(R.layout.view_floating_bubble, null)
        bubbleView = bubble

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 300
        }
        bubbleParams = params

        var lastX = 0
        var lastY = 0
        var touchStartX = 0f
        var touchStartY = 0f
        var isDragging = false

        bubble.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = params.x
                    lastY = params.y
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchStartX).toInt()
                    val dy = (event.rawY - touchStartY).toInt()
                    if (kotlin.math.abs(dx) > 6 || kotlin.math.abs(dy) > 6) {
                        isDragging = true
                    }
                    params.x = lastX + dx
                    params.y = lastY + dy
                    windowManager.updateViewLayout(bubble, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) togglePanel()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(bubble, params)
    }

    private fun togglePanel() {
        if (panelView == null) showPanel() else hidePanel()
    }

    private fun showPanel() {
        val inflater = LayoutInflater.from(this)
        val panel = inflater.inflate(R.layout.view_floating_panel, null)
        panelView = panel

        panel.findViewById<View>(R.id.btn_close_panel).setOnClickListener { hidePanel() }

        val modeBalanced = panel.findViewById<View>(R.id.mode_balanced)
        val modePowerSaver = panel.findViewById<View>(R.id.mode_power_saver)
        val modeExtreme = panel.findViewById<View>(R.id.mode_extreme)

        modeBalanced.setOnClickListener { applyPerfMode(PerfMode.BALANCED) }
        modePowerSaver.setOnClickListener { applyPerfMode(PerfMode.POWER_SAVER) }
        modeExtreme.setOnClickListener { applyPerfMode(PerfMode.EXTREME) }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (bubbleParams?.x ?: 24)
            y = (bubbleParams?.y ?: 300) + 130
        }

        windowManager.addView(panel, params)
    }

    private fun hidePanel() {
        panelView?.let { windowManager.removeView(it) }
        panelView = null
    }

    private fun removeFloatingViews() {
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        panelView?.let { runCatching { windowManager.removeView(it) } }
        bubbleView = null
        panelView = null
    }

    // ==========================================================
    // MODE PERFORMA
    // ==========================================================
    private fun applyPerfMode(mode: PerfMode) {
        currentMode = mode

        when (mode) {
            PerfMode.BALANCED -> {
                pollIntervalMs = BALANCED_POLL_MS
                Process.setThreadPriority(Process.THREAD_PRIORITY_DEFAULT)
                NativeBridge.execFireAndForget("settings put global sync_enabled 1")
            }
            PerfMode.POWER_SAVER -> {
                pollIntervalMs = POWER_SAVER_POLL_MS
                Process.setThreadPriority(Process.THREAD_PRIORITY_LOWEST)
                NativeBridge.execFireAndForget("settings put global sync_enabled 0")
            }
            PerfMode.EXTREME -> {
                pollIntervalMs = EXTREME_POLL_MS
                // Prioritas tinggi untuk proses layanan overlay sendiri —
                // BUKAN mengubah skala animasi sistem (dilarang).
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
                NativeBridge.execFireAndForget("settings put global sync_enabled 0")
                // Best-effort: lepaskan RAM dari aplikasi latar belakang.
                NativeBridge.execFireAndForget("am kill-all")
            }
        }

        panelView?.let { refreshModeSelection(it) }
    }

    private fun refreshModeSelection(panel: View) {
        val map = mapOf(
            PerfMode.BALANCED to R.id.mode_balanced,
            PerfMode.POWER_SAVER to R.id.mode_power_saver,
            PerfMode.EXTREME to R.id.mode_extreme,
        )
        map.forEach { (mode, id) ->
            panel.findViewById<View>(id).isSelected = (mode == currentMode)
        }
    }

    private fun PerfMode.label(): String = when (this) {
        PerfMode.BALANCED -> "Seimbang"
        PerfMode.POWER_SAVER -> "Hemat Daya"
        PerfMode.EXTREME -> "Performa"
    }

    // ==========================================================
    // POLLING STATISTIK (FPS overlay ringan / RAM)
    // ==========================================================
    private val startedAt = System.currentTimeMillis()

    private fun startStatsPolling() {
        val runnable = object : Runnable {
            override fun run() {
                val stats = NativeBridge.readSystemStats()
                panelView?.findViewById<TextView>(R.id.stat_ram)?.text =
                    "${(stats.totalRamKb - stats.availableRamKb) / 1024}MB"

                val elapsed = (System.currentTimeMillis() - startedAt) / 1000
                val uptime = String.format(
                    "%02d:%02d:%02d",
                    elapsed / 3600, (elapsed % 3600) / 60, elapsed % 60
                )
                updateNotification(uptime)

                statsHandler.postDelayed(this, pollIntervalMs)
            }
        }
        statsHandler.post(runnable)
    }
}
