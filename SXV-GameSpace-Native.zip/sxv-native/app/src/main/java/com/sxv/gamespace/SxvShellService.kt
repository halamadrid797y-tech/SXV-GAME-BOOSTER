package com.sxv.gamespace

import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * SxvShellService
 * ------------------------------------------------------------
 * Diinstansiasi oleh Shizuku sendiri di proses terpisah yang
 * berjalan dengan UID shell (2000) — bukan UID aplikasi biasa.
 * Didaftarkan lewat Shizuku.bindUserService() dari NativeBridge.
 *
 * PENTING: kelas ini TIDAK melakukan validasi ulang command.
 * Validasi (termasuk blokir window_animation_scale dkk.) sudah
 * WAJIB dilakukan sebelumnya oleh SxvCoreEngine (native) di
 * NativeBridge.exec(). Service ini murni eksekutor.
 */
class SxvShellService : ISxvShellService.Stub() {

    companion object {
        private const val TAG = "SxvShellService"
    }

    override fun exec(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()

            val output = BufferedReader(InputStreamReader(process.inputStream))
                .readText()
            process.waitFor()
            output
        } catch (t: Throwable) {
            Log.e(TAG, "exec gagal untuk: $command", t)
            "ERROR: ${t.message}"
        }
    }

    override fun execFireAndForget(command: String) {
        try {
            ProcessBuilder("sh", "-c", command).start()
        } catch (t: Throwable) {
            Log.e(TAG, "execFireAndForget gagal untuk: $command", t)
        }
    }

    override fun getRunningUid(): Int = android.os.Process.myUid()

    // Dipanggil Shizuku saat proses user-service akan dihentikan.
    fun destroy() {
        Log.i(TAG, "SxvShellService dihentikan")
    }
}
