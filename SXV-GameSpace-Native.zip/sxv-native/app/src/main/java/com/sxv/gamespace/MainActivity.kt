package com.sxv.gamespace

import android.app.AppOpsManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.TextView
import android.widget.ViewFlipper
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var flipper: ViewFlipper

    // ---- Step 1: Setup views ----
    private lateinit var inputPort: EditText
    private lateinit var inputPairCode: EditText
    private lateinit var chipAdbStatus: TextView
    private lateinit var chipShizukuStatus: TextView
    private lateinit var btnContinueToPermissions: android.widget.Button

    // ---- Step 2: Permission views ----
    private lateinit var toggleOverlay: CompoundButton
    private lateinit var toggleNotification: CompoundButton
    private lateinit var toggleBattery: CompoundButton
    private lateinit var chipOverlay: TextView
    private lateinit var chipNotification: TextView
    private lateinit var chipBattery: TextView
    private lateinit var btnContinueToDashboard: android.widget.Button

    // ---- Step 3: Dashboard views ----
    private lateinit var engineStatusText: TextView
    private lateinit var btnLaunchGame: android.widget.Button
    private lateinit var btnCacheCleaner: android.widget.Button
    private lateinit var btnTaskManager: android.widget.Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        NativeBridge.initialize()
        NativeBridge.onShizukuStateChanged = { connected ->
            runOnUiThread { onShizukuStateChanged(connected) }
        }

        flipper = findViewById(R.id.step_flipper)
        bindSetupStep()
        bindPermissionStep()
        bindDashboardStep()
    }

    override fun onDestroy() {
        NativeBridge.release()
        super.onDestroy()
    }

    // ==========================================================
    // STEP 1 — SETUP KONEKSI ADB / SHIZUKU
    // ==========================================================
    private fun bindSetupStep() {
        val step = findViewById<android.view.View>(R.id.step_setup)
        inputPort = step.findViewById(R.id.input_adb_port)
        inputPairCode = step.findViewById(R.id.input_adb_pair)
        chipAdbStatus = step.findViewById(R.id.chip_adb_status)
        chipShizukuStatus = step.findViewById(R.id.chip_shizuku_status)
        btnContinueToPermissions = step.findViewById(R.id.btn_goto_permissions)

        step.findViewById<android.widget.Button>(R.id.btn_open_dev_options).setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        }

        step.findViewById<android.widget.Button>(R.id.btn_connect_adb).setOnClickListener {
            val port = inputPort.text.toString()
            val pair = inputPairCode.text.toString()
            if (port.isBlank() || pair.isBlank()) {
                chipAdbStatus.text = "Port/Kode Belum Lengkap"
                return@setOnClickListener
            }
            // Pairing wireless-debugging sesungguhnya ditangani oleh
            // aplikasi Shizuku (lihat catatan di NativeBridge.connectShizuku).
            // Field ini disimpan untuk kelengkapan alur & referensi log.
            chipAdbStatus.text = "Menunggu Shizuku..."
            NativeBridge.connectShizuku()
        }

        step.findViewById<android.widget.Button>(R.id.btn_connect_shizuku).setOnClickListener {
            chipShizukuStatus.text = "Menghubungkan..."
            if (!NativeBridge.isShizukuAvailable()) {
                chipShizukuStatus.text = "Buka Aplikasi Shizuku"
                openShizukuApp()
            } else {
                NativeBridge.connectShizuku()
            }
        }

        btnContinueToPermissions.setOnClickListener {
            flipper.showNext()
        }
    }

    private fun openShizukuApp() {
        val shizukuPackage = "moe.shizuku.privileged.api"
        val launchIntent = packageManager.getLaunchIntentForPackage(shizukuPackage)
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=$shizukuPackage")
                )
            )
        }
    }

    private fun onShizukuStateChanged(connected: Boolean) {
        chipShizukuStatus.text = if (connected) "Terhubung" else "Belum Terhubung"
        chipAdbStatus.text = if (connected) "Terhubung" else "Belum Terhubung"
        btnContinueToPermissions.isEnabled = connected
    }

    // ==========================================================
    // STEP 2 — PEMERIKSAAN IZIN SISTEM
    // ==========================================================
    private fun bindPermissionStep() {
        val step = findViewById<android.view.View>(R.id.step_permissions)
        toggleOverlay = step.findViewById(R.id.toggle_overlay)
        toggleNotification = step.findViewById(R.id.toggle_notification)
        toggleBattery = step.findViewById(R.id.toggle_battery)
        chipOverlay = step.findViewById(R.id.chip_overlay)
        chipNotification = step.findViewById(R.id.chip_notification)
        chipBattery = step.findViewById(R.id.chip_battery)
        btnContinueToDashboard = step.findViewById(R.id.btn_goto_dashboard)

        toggleOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
        toggleNotification.setOnClickListener {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            })
        }
        toggleBattery.setOnClickListener {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }

        btnContinueToDashboard.setOnClickListener {
            flipper.showNext()
            startFloatingServiceIfPermitted()
        }
    }

    /** Dipanggil di onResume agar status toggle selalu sinkron dengan sistem. */
    private fun refreshPermissionStates() {
        val overlayGranted = Settings.canDrawOverlays(this)
        val notifGranted = NotificationManagerCompat.from(this).areNotificationsEnabled()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val batteryGranted = pm.isIgnoringBatteryOptimizations(packageName)

        toggleOverlay.isChecked = overlayGranted
        chipOverlay.text = if (overlayGranted) "Diizinkan" else "Belum Diizinkan"

        toggleNotification.isChecked = notifGranted
        chipNotification.text = if (notifGranted) "Diizinkan" else "Belum Diizinkan"

        toggleBattery.isChecked = batteryGranted
        chipBattery.text = if (batteryGranted) "Diizinkan" else "Belum Diizinkan"
    }

    override fun onResume() {
        super.onResume()
        if (::toggleOverlay.isInitialized) refreshPermissionStates()
    }

    private fun startFloatingServiceIfPermitted() {
        if (Settings.canDrawOverlays(this)) {
            val intent = Intent(this, FloatingService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        }
    }

    // ==========================================================
    // STEP 3 — DASHBOARD
    // ==========================================================
    private fun bindDashboardStep() {
        val step = findViewById<android.view.View>(R.id.step_dashboard)
        engineStatusText = step.findViewById(R.id.text_engine_status)
        btnLaunchGame = step.findViewById(R.id.btn_launch_game)
        btnCacheCleaner = step.findViewById(R.id.btn_cache_cleaner)
        btnTaskManager = step.findViewById(R.id.btn_task_manager)

        btnLaunchGame.setOnClickListener {
            LaunchGameDialogFragment.newInstance(
                gameName = "Free Fire MAX",
                packageName = "com.dts.freefireth",
                versionLabel = "v1.0",
                userId = "346238"
            ).show(supportFragmentManager, "launch_game")
        }

        btnCacheCleaner.setOnClickListener {
            NativeBridge.execFireAndForget("pm trim-caches 999999999")
        }

        btnTaskManager.setOnClickListener {
            NativeBridge.execFireAndForget("am kill-all")
        }

        wireSegmented(step, R.id.segmented_touch_accel, mapOf(
            R.id.opt_touch_cepat to null, // penyesuaian di sisi UI saja
            R.id.opt_touch_super_cepat to null,
            R.id.opt_touch_booster to null,
        ))

        wireRendererSegmented(step)
    }

    private fun wireSegmented(
        root: android.view.View,
        groupId: Int,
        options: Map<Int, String?>
    ) {
        val group = root.findViewById<android.view.ViewGroup>(groupId)
        for (i in 0 until group.childCount) {
            val child = group.getChildAt(i)
            child.setOnClickListener {
                for (j in 0 until group.childCount) group.getChildAt(j).isSelected = false
                child.isSelected = true
            }
        }
    }

    private fun wireRendererSegmented(root: android.view.View) {
        val group = root.findViewById<android.view.ViewGroup>(R.id.segmented_renderer)
        val commands = mapOf(
            R.id.opt_renderer_vulkan to "setprop debug.hwui.renderer skiavk",
            R.id.opt_renderer_opengl to "setprop debug.hwui.renderer skiagl",
            R.id.opt_renderer_angle to "settings put global angle_gl_driver_selection_pkgs $packageName",
        )
        for (i in 0 until group.childCount) {
            val child = group.getChildAt(i)
            child.setOnClickListener {
                for (j in 0 until group.childCount) group.getChildAt(j).isSelected = false
                child.isSelected = true
                commands[child.id]?.let { cmd -> NativeBridge.execFireAndForget(cmd) }
            }
        }
    }
}
