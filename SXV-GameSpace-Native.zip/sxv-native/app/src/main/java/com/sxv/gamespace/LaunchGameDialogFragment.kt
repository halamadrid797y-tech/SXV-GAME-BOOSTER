package com.sxv.gamespace

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.DialogFragment

/**
 * LaunchGameDialogFragment
 * ------------------------------------------------------------
 * Popup peluncuran game. Ketentuan brief:
 *   - Countdown 10 -> 0 detik.
 *   - TIDAK ADA animasi splash screen / logo isian.
 *   - TIDAK ADA banner/teks "Beli Premium".
 *   - Setelah 0, tombol ">>>" aktif / auto-launch.
 */
class LaunchGameDialogFragment : DialogFragment() {

    companion object {
        private const val ARG_GAME_NAME = "arg_game_name"
        private const val ARG_PACKAGE_NAME = "arg_package_name"
        private const val ARG_VERSION = "arg_version"
        private const val ARG_USER_ID = "arg_user_id"

        fun newInstance(
            gameName: String,
            packageName: String,
            versionLabel: String,
            userId: String
        ) = LaunchGameDialogFragment().apply {
            arguments = Bundle().apply {
                putString(ARG_GAME_NAME, gameName)
                putString(ARG_PACKAGE_NAME, packageName)
                putString(ARG_VERSION, versionLabel)
                putString(ARG_USER_ID, userId)
            }
        }
    }

    private var countDownTimer: CountDownTimer? = null
    private var launchMode: String = "core_boost"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.dialog_launch_game, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val gameName = requireArguments().getString(ARG_GAME_NAME).orEmpty()
        val pkg = requireArguments().getString(ARG_PACKAGE_NAME).orEmpty()
        val version = requireArguments().getString(ARG_VERSION).orEmpty()
        val userId = requireArguments().getString(ARG_USER_ID).orEmpty()

        view.findViewById<TextView>(R.id.text_game_name).text = gameName
        view.findViewById<TextView>(R.id.text_game_meta).text = "$pkg · $version"
        view.findViewById<TextView>(R.id.text_game_id).text = "ID $userId"

        val countdownText = view.findViewById<TextView>(R.id.text_countdown)
        val btnLaunchNow = view.findViewById<android.widget.Button>(R.id.btn_launch_now)
        val btnCancel = view.findViewById<android.widget.Button>(R.id.btn_cancel)

        val modeCoreBoost = view.findViewById<View>(R.id.mode_core_boost)
        val modeDirect = view.findViewById<View>(R.id.mode_direct)
        modeCoreBoost.isSelected = true
        modeCoreBoost.setOnClickListener {
            launchMode = "core_boost"
            modeCoreBoost.isSelected = true
            modeDirect.isSelected = false
        }
        modeDirect.setOnClickListener {
            launchMode = "direct"
            modeDirect.isSelected = true
            modeCoreBoost.isSelected = false
        }

        btnCancel.setOnClickListener { dismiss() }
        btnLaunchNow.setOnClickListener {
            countDownTimer?.cancel()
            launchGame(pkg)
        }

        // Countdown polos: hanya angka berkurang, tanpa animasi/efek apa pun.
        countDownTimer = object : CountDownTimer(10_000, 1_000) {
            override fun onTick(millisUntilFinished: Long) {
                val secondsLeft = (millisUntilFinished / 1000).toInt() + 1
                countdownText.text = secondsLeft.coerceAtMost(10).toString()
            }

            override fun onFinish() {
                countdownText.text = "0"
                launchGame(pkg)
            }
        }.start()
    }

    private fun launchGame(pkg: String) {
        // SXV Core Boost: terapkan preferensi (renderer/DPI) yang sudah
        // dipilih pengguna sebelum membuka game. Direct Open: langsung.
        if (launchMode == "core_boost") {
            NativeBridge.execFireAndForget("am force-stop $pkg")
        }
        val launchIntent = requireContext().packageManager.getLaunchIntentForPackage(pkg)
        if (launchIntent != null) {
            startActivity(launchIntent)
        }
        dismiss()
    }

    override fun onDestroyView() {
        countDownTimer?.cancel()
        super.onDestroyView()
    }
}
