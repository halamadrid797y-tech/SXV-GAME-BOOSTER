# Aturan ProGuard/R8 khusus SXV Game Space
-keep class com.sxv.gamespace.ISxvShellService { *; }
-keep class com.sxv.gamespace.ISxvShellService$Stub { *; }
-keep class com.sxv.gamespace.SxvShellService { *; }
